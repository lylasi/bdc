import * as state from './state.js';
import * as readingStore from './reading-store.js';
import * as articleStore from './article-store.js';
import { touch as syncTouch } from './sync-signals.js';
import { t } from './i18n.js';

// =================================
// 本地存儲管理 (LocalStorage)
// =================================

// 文章 metadata 存儲 key
const ARTICLE_METAS_KEY = 'articleMetas';
const DICTATION_UPDATED_AT_KEY = 'dictationUpdatedAt';

/**
 * 安全讀取 localStorage 中的 JSON 陣列。
 * 內容損壞（parse 失敗或非陣列）時不讓啟動流程崩潰：
 * 先把原始內容備份到 `<key>.corrupt` 供救援，再回退為空陣列。
 */
function safeParseArray(key) {
    let raw = null;
    try {
        raw = localStorage.getItem(key);
    } catch (_) {
        return [];
    }
    if (!raw) return [];
    try {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return parsed;
    } catch (_) { /* fallthrough：視同損壞 */ }
    try { localStorage.setItem(`${key}.corrupt`, raw); } catch (_) {}
    console.warn(`[storage] localStorage 鍵 "${key}" 內容損壞，已備份至 "${key}.corrupt" 並回退為空陣列`);
    return [];
}

function normalizePersistOptions(options = {}) {
    if (typeof options === 'boolean') {
        return { preserveUpdatedAt: options };
    }
    return options && typeof options === 'object' ? options : {};
}

function updateGroupPersistence(updatedAtKey, group, options = {}) {
    const normalizedOptions = normalizePersistOptions(options);
    let effectiveUpdatedAt = '';

    try {
        if (typeof normalizedOptions.updatedAtOverride === 'string' && normalizedOptions.updatedAtOverride) {
            effectiveUpdatedAt = normalizedOptions.updatedAtOverride;
            localStorage.setItem(updatedAtKey, effectiveUpdatedAt);
        } else if (normalizedOptions.preserveUpdatedAt !== true) {
            effectiveUpdatedAt = new Date().toISOString();
            localStorage.setItem(updatedAtKey, effectiveUpdatedAt);
        } else {
            effectiveUpdatedAt = String(localStorage.getItem(updatedAtKey) || '');
        }
    } catch (_) {
        effectiveUpdatedAt = typeof normalizedOptions.updatedAtOverride === 'string'
            ? normalizedOptions.updatedAtOverride
            : '';
    }

    if (normalizedOptions.suppressSyncTouch !== true) {
        try { syncTouch(group); } catch (_) {}
    }

    return {
        ...normalizedOptions,
        effectiveUpdatedAt
    };
}

// --- ArticleMeta helpers ---

function generateArticleShareId() {
    return `art_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
}

function readArticleMetasMap() {
    try {
        const raw = localStorage.getItem(ARTICLE_METAS_KEY);
        if (!raw) return {};
        const parsed = JSON.parse(raw);
        // 僅接受物件類型，避免舊資料污染
        return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
    } catch (_) {
        return {};
    }
}

function writeArticleMetasMap(map, options = {}) {
    try {
        localStorage.setItem(ARTICLE_METAS_KEY, JSON.stringify(map));
        updateGroupPersistence('articlesUpdatedAt', 'articles', options);
    } catch (_) {
        // 保守處理，避免因 localStorage 錯誤導致應用崩潰
    }
}

/**
 * 依 ID 取得單一文章 metadata。
 */
export function getArticleMetaById(articleId) {
    if (!articleId) return null;
    const map = readArticleMetasMap();
    const meta = map[articleId];
    return meta || null;
}

/**
 * 取得全部文章 metadata 列表。
 */
export function getAllArticleMetas() {
    const map = readArticleMetasMap();
    return Object.values(map);
}

/**
 * 新增或更新文章 metadata。
 */
export function saveArticleMeta(articleMeta, options = {}) {
    if (!articleMeta || !articleMeta.id) return null;
    const map = readArticleMetasMap();
    const normalized = {
        ...articleMeta,
        createdAt: typeof articleMeta.createdAt === 'number'
            ? articleMeta.createdAt
            : Date.now()
    };
    if (!normalized.shareId) {
        normalized.shareId = generateArticleShareId();
    }
    map[normalized.id] = normalized;
    writeArticleMetasMap(map, options);
    return normalized;
}

export function deleteArticleMetaById(articleId, options = {}) {
    if (!articleId) return false;
    const map = readArticleMetasMap();
    if (!Object.prototype.hasOwnProperty.call(map, articleId)) return false;
    delete map[articleId];
    writeArticleMetasMap(map, options);
    return true;
}

export function replaceArticleMetas(articleMetas, options = {}) {
    const list = Array.isArray(articleMetas) ? articleMetas : [];
    const nextMap = {};
    list.forEach(meta => {
        if (!meta || !meta.id) return;
        const normalized = {
            ...meta,
            createdAt: typeof meta.createdAt === 'number'
                ? meta.createdAt
                : Date.now(),
            shareId: meta.shareId || generateArticleShareId()
        };
        nextMap[normalized.id] = normalized;
    });
    writeArticleMetasMap(nextMap, options);
    return Object.values(nextMap);
}

/**
 * 依 URL 尋找文章 metadata（僅 sourceType = 'url'）。
 */
export function findArticleMetaByUrl(url) {
    if (!url) return null;
    const metas = getAllArticleMetas();
    const normalizedUrl = String(url).trim();
    return metas.find(m => m && m.sourceType === 'url' && m.sourceUrl === normalizedUrl) || null;
}

// --- 單詞本存儲 ---

/**
 * 將目前單詞本視圖同步到永久層；永久層成功後才更新相容用 localStorage。
 * 回傳 Promise<{ok,error?}>，呼叫端若需要「不得顯示成功」必須 await。
 */
export function saveVocabularyBooks(options = {}) {
    const normalizedOptions = normalizePersistOptions(options);
    let snapshot = [];
    try { snapshot = JSON.parse(JSON.stringify(state.vocabularyBooks || [])); } catch (_) { snapshot = Array.isArray(state.vocabularyBooks) ? [...state.vocabularyBooks] : []; }

    const writeCompatibilityView = () => {
        try { localStorage.setItem('vocabularyBooks', JSON.stringify(snapshot)); } catch (_) {}
        updateGroupPersistence('vocabularyUpdatedAt', 'vocabulary', normalizedOptions);
    };
    if (normalizedOptions.suppressPermanent === true) {
        writeCompatibilityView();
        return Promise.resolve({ ok: true, suppressed: true });
    }
    return Promise.resolve()
        .then(() => readingStore.syncVocabularyFromMemory(snapshot))
        .then((result) => {
            if (!result || !result.ok) {
                const error = result?.error || 'save_failed';
                try {
                    document.dispatchEvent(new CustomEvent('bdc:reading-save-error', {
                        detail: { scope: 'vocabulary', error }
                    }));
                } catch (_) {}
                return { ok: false, error };
            }
            writeCompatibilityView();
            return result;
        })
        .catch((error) => {
            const code = error?.code || error?.message || 'save_failed';
            try {
                document.dispatchEvent(new CustomEvent('bdc:reading-save-error', {
                    detail: { scope: 'vocabulary', error: code }
                }));
            } catch (_) {}
            return { ok: false, error: code };
        });
}

/**
 * 從 localStorage 加載單詞本數據。
 * 注意：不再自動建立任何預設單詞本，保持為空以引導使用者自行「導入 / 新建」。
 * 同時包含一個數據遷移邏輯，用於清理舊數據格式。
 */
export function loadVocabularyBooks() {
    // 遷移完成後永久層是唯一權威；即使目前是空的，也不回讀舊 localStorage，
    // 否則已刪除的詞書或上一個帳戶的資料會復活。只有遷移失敗時才用舊視圖。
    let books = [];
    let migrated = false;
    try { migrated = readingStore.isReadingMigrated(); } catch (_) {}
    try { books = readingStore.vocabularyBooksForUi(); } catch (_) { books = []; }
    if (!migrated) books = safeParseArray('vocabularyBooks');

    if (books.length > 0) {
        // 資料遷移和清理：遍歷所有單詞並標準化音標格式，同時補齊生詞本 metadata
        let dataWasModified = false;
        books.forEach(book => {
            if (book && typeof book === 'object') {
                // 若缺少來源類型，視為舊資料（legacy）
                if (!book.sourceType) {
                    book.sourceType = 'legacy';
                    dataWasModified = true;
                }
                // 若缺少建立時間，補上一個合理的預設值
                if (!book.createdAt) {
                    try {
                        book.createdAt = new Date().toISOString();
                        dataWasModified = true;
                    } catch (_) { /* ignore */ }
                }
                // 若缺少共享用唯一 ID，則補上一個
                if (!book.shareId) {
                    book.shareId = generateBookShareId();
                    dataWasModified = true;
                }
            }

            if (book && book.words && Array.isArray(book.words)) {
                book.words.forEach((word, index) => {
                    if (!word.id) {
                        word.id = `${book.id || 'book'}-word-${index + 1}`;
                        dataWasModified = true;
                    }
                    if (!word.meaning && typeof word.definition === 'string' && word.definition.trim()) {
                        word.meaning = word.definition.trim();
                        dataWasModified = true;
                    }
                    if (word.phonetic && typeof word.phonetic === 'string') {
                        const originalPhonetic = word.phonetic;
                        const cleanedPhonetic = originalPhonetic.replace(/^\/+|\/+$/g, '');
                        if (originalPhonetic !== cleanedPhonetic) {
                            word.phonetic = cleanedPhonetic;
                            dataWasModified = true;
                        }
                    }
                });
            }
        });
        // 如果資料被修改過，就立即存回localStorage
        if (dataWasModified) {
            // 僅在資料被修正時才回寫，避免無謂的寫入
            localStorage.setItem('vocabularyBooks', JSON.stringify(books));
        }
    }

    state.setVocabularyBooks(books);
    loadAppState(); // 加載完書籍後，加載應用狀態（依賴書籍數據）
}

function generateBookShareId() {
    return `wb_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
}

function ensureBookShareId(book) {
    if (!book || typeof book !== 'object') return book;
    if (!book.shareId) {
        book.shareId = generateBookShareId();
    }
    return book;
}

/**
 * 依 ID 取得生詞本。
 */
export function getWordbookById(wordbookId) {
    if (!wordbookId) return null;
    const book = state.vocabularyBooks.find(b => b.id === wordbookId) || null;
    return book ? ensureBookShareId(book) : null;
}

/**
 * 取得所有生詞本。
 */
export function getAllWordbooks() {
    const books = Array.isArray(state.vocabularyBooks) ? state.vocabularyBooks : [];
    return books.map(b => ensureBookShareId(b));
}

/**
 * 新增或更新生詞本，並持久化。
 */
export function saveWordbook(wordbook, options = {}) {
    if (!wordbook || !wordbook.id) return null;
    const normalizedBook = ensureBookShareId({ ...wordbook });
    const books = Array.isArray(state.vocabularyBooks) ? [...state.vocabularyBooks] : [];
    const index = books.findIndex(b => b.id === normalizedBook.id);
    if (index === -1) {
        books.push(normalizedBook);
    } else {
        books[index] = normalizedBook;
    }
    state.setVocabularyBooks(books);
    saveVocabularyBooks(options);
    return normalizedBook;
}

/**
 * 取得某個生詞本底下的所有單字。
 */
export function getWordsByWordbookId(wordbookId) {
    const book = getWordbookById(wordbookId);
    if (!book || !Array.isArray(book.words)) return [];
    return book.words;
}

function generateWordEntryId() {
    return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

/**
 * 在指定生詞本底下新增單字。
 * wordPayload 不需要包含 id / wordbookId，會在此處補上。
 */
export function addWordToWordbook(wordbookId, wordPayload) {
    const book = getWordbookById(wordbookId);
    if (!book) {
        throw new Error(t('errors.wordbookNotFound', { id: wordbookId }));
    }
    const words = Array.isArray(book.words) ? [...book.words] : [];
    const id = wordPayload && wordPayload.id ? wordPayload.id : generateWordEntryId();
    const newWord = {
        ...wordPayload,
        id,
        wordbookId
    };
    words.push(newWord);
    const nextBook = { ...book, words };
    saveWordbook(nextBook);
    return newWord;
}

/**
 * 更新指定生詞本中的單字。
 */
export function updateWordInWordbook(wordbookId, wordEntry) {
    if (!wordEntry || !wordEntry.id) return null;
    const book = getWordbookById(wordbookId);
    if (!book || !Array.isArray(book.words)) return null;
    const words = [...book.words];
    const index = words.findIndex(w => w.id === wordEntry.id);
    if (index === -1) return null;
    words[index] = { ...words[index], ...wordEntry };
    const nextBook = { ...book, words };
    saveWordbook(nextBook);
    return words[index];
}

/**
 * 從生詞本刪除單字。
 */
export function removeWordFromWordbook(wordbookId, wordEntryId) {
    const book = getWordbookById(wordbookId);
    if (!book || !Array.isArray(book.words)) return;
    const words = book.words;
    const nextWords = words.filter(w => w.id !== wordEntryId);
    if (nextWords.length === words.length) return;
    const nextBook = { ...book, words: nextWords };
    saveWordbook(nextBook);
    // 移出詞書只移除詞條與有效來源關聯；文章學習條目、標記與筆記保留。
    try { readingStore.removeVocabularyEntry(wordEntryId).catch(() => {}); } catch (_) {}
}

/**
 * 確保文章專屬生詞本存在：
 * - 生成或查找 ArticleMeta
 * - 生成或查找對應的生詞本（id = articleId）
 * - 更新當前文章 / 生詞本上下文
 * 回傳 { articleMeta, wordbook }
 */
export function getOrCreateArticleWordbook(articleMetaInput, options = {}) {
    const createWordbook = options.createWordbook !== false;
    if (!articleMetaInput || !articleMetaInput.title || !articleMetaInput.sourceType) {
        throw new Error(t('errors.articleMetaInvalid'));
    }

    const sourceType = articleMetaInput.sourceType;
    const sourceUrl = articleMetaInput.sourceUrl;
    let articleMeta = null;

    // 1. 先處理 ID 與已有的 ArticleMeta
    if (articleMetaInput.id) {
        const existing = getArticleMetaById(articleMetaInput.id);
        articleMeta = {
            ...existing,
            ...articleMetaInput,
            id: articleMetaInput.id
        };
    } else if (sourceType === 'url' && sourceUrl) {
        // URL 來源：盡量重用既有 meta
        const existingByUrl = findArticleMetaByUrl(sourceUrl);
        if (existingByUrl) {
            articleMeta = {
                ...existingByUrl,
                ...articleMetaInput,
                id: existingByUrl.id
            };
        } else {
            const encoded = encodeURIComponent(String(sourceUrl).trim());
            articleMeta = {
                ...articleMetaInput,
                id: `url:${encoded}`
            };
        }
    } else {
        // 其他來源：生成 local: 開頭的 id
        const randomId = `local:${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
        articleMeta = {
            ...articleMetaInput,
            id: randomId
        };
    }

    if (typeof articleMeta.createdAt !== 'number') {
        articleMeta.createdAt = Date.now();
    }

    articleMeta = saveArticleMeta(articleMeta);

    // 2. 沿用已關聯的頁面詞書；舊文章仍以 articleMeta.id 建立詞書。
    const wordbookId = articleMeta.id;
    const existingBook = getWordbookById(wordbookId)
        || state.vocabularyBooks.find((book) => !book.deletedAt && book.sourceType === 'article' && book.articleId === articleMeta.id);

    const nowIso = new Date().toISOString();
    let nextBook;

    if (existingBook) {
        nextBook = {
            ...existingBook,
            sourceType: existingBook.sourceType || 'article',
            articleId: existingBook.articleId || articleMeta.id,
            name: existingBook.name || articleMeta.title,
            createdAt: existingBook.createdAt || nowIso
        };
    } else if (createWordbook) {
        nextBook = {
            id: wordbookId,
            name: articleMeta.title || t('errors.untitledArticle'),
            words: [],
            sourceType: 'article',
            articleId: articleMeta.id,
            createdAt: nowIso
        };
    } else {
        nextBook = null;
    }

    const savedBook = nextBook ? saveWordbook(nextBook) : null;

    // 3. 更新當前上下文
    try {
        if (typeof state.setCurrentArticleId === 'function') {
            state.setCurrentArticleId(articleMeta.id);
        }
        if (typeof state.setCurrentWordbookId === 'function') {
            const wbId = (savedBook || existingBook || {}).id || null;
            state.setCurrentWordbookId(wbId);
        }
    } catch (_) { /* ignore */ }

    return { articleMeta, wordbook: savedBook || existingBook || null };
}

// --- 應用程序狀態存儲 ---

/**
 * 保存當前激活的單詞本ID。
 */
export function saveAppState(options = {}) {
    const normalizedOptions = normalizePersistOptions(options);
    localStorage.setItem('activeBookId', state.activeBookId);
    // 變更當前書視為 vocabulary 分組的變更
    updateGroupPersistence('vocabularyUpdatedAt', 'vocabulary', normalizedOptions);
}

/**
 * 加載上次激活的單詞本ID。
 * 如果找不到或無效，則默認選擇第一個單詞本。
 */
export function loadAppState() {
    const savedId = localStorage.getItem('activeBookId');
    if (savedId && state.vocabularyBooks.some(b => b.id === savedId)) {
        state.setActiveBookId(savedId);
    } else if (state.vocabularyBooks.length > 0) {
        state.setActiveBookId(state.vocabularyBooks[0].id);
    } else {
        state.setActiveBookId(null);
    }
}

// --- 文章分析歷史記錄存儲（已搬到 IndexedDB 逐篇儲存） ---
//
// 文章不再寫進同一個大 JSON（analyzedArticles）或同步快照。這個檔案只保留
// 相容轉接層，讓舊呼叫端仍能運作；真正的讀寫在 modules/article-store.js。
// 任何寫入失敗都會回報 `{ ok: false }`，不再靜默吞掉。

/**
 * 保存已分析的文章清單（相容函式）。
 * 新的儲存方式逐篇寫入 IndexedDB，因此這個函式只會觸發一次全量刷寫。
 */
export async function saveAnalyzedArticles(options = {}) {
    const normalizedOptions = normalizePersistOptions(options);
    const list = Array.isArray(state.analyzedArticles) ? state.analyzedArticles : [];
    let failed = 0;
    for (const item of list) {
        const result = await articleStore.saveArticle({
            articleId: item.articleId,
            article: item.article,
            result: item.result,
            title: item.title,
            sourceType: item.sourceType,
            sourceUrl: item.sourceUrl
        }, { skipOutbox: normalizedOptions.skipOutbox === true, touch: false });
        if (!result.ok) failed += 1;
    }
    if (failed) return { ok: false, error: 'article_save_failed', failed };
    return { ok: true, count: list.length };
}

/**
 * 載入文章清單（相容函式）。實際資料由 article-store 在啟動時 hydrate。
 */
export function loadAnalyzedArticles() {
    // 由 main.js 呼叫 articleStore.initArticleStore() 完成；這裡不再讀取
    // localStorage，避免新舊兩份資料同時存在。
    return state.analyzedArticles;
}

export async function deleteAnalyzedArticleByIndex(index, options = {}) {
    const normalizedIndex = Number.parseInt(index, 10);
    if (Number.isNaN(normalizedIndex) || normalizedIndex < 0) return null;
    const articles = Array.isArray(state.analyzedArticles) ? [...state.analyzedArticles] : [];
    if (normalizedIndex >= articles.length) return null;
    const removed = articles[normalizedIndex] || null;
    if (!removed || !removed.articleId) return null;
    const result = await articleStore.deleteArticle(removed.articleId, {
        skipOutbox: options.skipOutbox === true
    });
    if (!result.ok) return null;
    if (options.deleteMeta !== false) {
        deleteArticleMetaById(removed.articleId, {
            ...options,
            preserveUpdatedAt: true,
            suppressSyncTouch: true
        });
    }
    return removed;
}

export async function clearAnalyzedArticles(options = {}) {
    const removed = Array.isArray(state.analyzedArticles) ? [...state.analyzedArticles] : [];
    for (const item of removed) {
        if (!item || !item.articleId) continue;
        await articleStore.deleteArticle(item.articleId, { skipOutbox: options.skipOutbox === true });
        if (options.deleteMeta !== false) {
            deleteArticleMetaById(item.articleId, {
                ...options,
                preserveUpdatedAt: true,
                suppressSyncTouch: true
            });
        }
    }
    return removed;
}

/**
 * 保存單個文章的分析結果。
 * 如果已存在，則更新；否則，新增。
 * @param {string} article - 文章原文
 * @param {object} result - 分析結果對象
 * @param {object} [extra] - 額外資訊（例如 { articleId }）
 * @returns {Promise<{ok:boolean,error?:string}>} 持久化結果（呼叫端必須處理失敗）
 */
export async function saveAnalysisResult(article, result, extra = {}) {
    const articleId = extra && extra.articleId ? String(extra.articleId) : '';
    const record = articleId ? articleStore.getRecord(articleId) : null;
    const saved = await articleStore.saveArticle({
        articleId,
        article,
        result,
        title: record?.title,
        sourceType: record?.sourceType,
        sourceUrl: record?.sourceUrl
    });
    if (!saved.ok) {
        console.warn('[storage] 文章未能寫入本機儲存:', saved.error);
    }
    return saved;
}

// --- 默寫 AI 批改歷史（LocalStorage） ---
const GRADING_HISTORY_KEY = 'dictationGradingHistory';

function saveGradingHistoryList(list, options = {}) {
    const normalizedOptions = normalizePersistOptions(options);
    try {
        if (Array.isArray(list) && list.length > 0) {
            localStorage.setItem(GRADING_HISTORY_KEY, JSON.stringify(list.slice(0, 200)));
        } else {
            localStorage.removeItem(GRADING_HISTORY_KEY);
        }
    } catch (_) {}
    return updateGroupPersistence(DICTATION_UPDATED_AT_KEY, 'dictation', normalizedOptions);
}

export function getGradingHistory() {
    try {
        const raw = localStorage.getItem(GRADING_HISTORY_KEY);
        return raw ? JSON.parse(raw) : [];
    } catch (_) { return []; }
}

export function saveGradingRecord(record, options = {}) {
    const list = getGradingHistory();
    // ensure id
    const id = record && record.id ? record.id : `${Date.now()}-${Math.random().toString(36).slice(2,8)}`;
    const createdAt = record && record.createdAt ? record.createdAt : new Date().toISOString();
    const normalized = { id, createdAt, ...record };
    list.unshift(normalized);
    saveGradingHistoryList(list, options);
    return normalized;
}

export function saveGradingHistory(records, options = {}) {
    const list = Array.isArray(records) ? records : [];
    saveGradingHistoryList(list, options);
    return list.slice(0, 200);
}

export function deleteGradingRecord(id, options = {}) {
    const list = getGradingHistory();
    const next = list.filter(x => x.id !== id);
    saveGradingHistoryList(next, options);
}

export function clearGradingHistory(options = {}) {
    saveGradingHistoryList([], options);
}

